@echo off
rem Serves the multi-drone viewer from this computer, so this laptop and any phone or tablet on
rem the same network can open it. It has to come from an http:// address or a local file: a
rem browser will not let a secure (https) page connect to a ground station.
cd /d "%~dp0"
echo.
echo  SkyShield RVT - multi-drone viewer
echo.
echo  On this computer:   http://localhost:8090
echo  On another device:  http://[this computer's network address]:8090
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo                     http://%%a:8090
echo.
echo  Leave this window open while the viewer is in use. Close it to stop.
echo.
start "" http://localhost:8090
python -m http.server 8090 --bind 0.0.0.0
