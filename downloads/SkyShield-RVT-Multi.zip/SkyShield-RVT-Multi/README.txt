SkyShield RVT Multi - multi-drone viewer
========================================

Watch several SkyShield ground stations at once: live video, map, AI boxes and alerts.

To use it on this computer
  1. Double-click index.html. It opens in your browser (Chrome or Edge recommended).
  2. On each ground station, open Video Terminal, turn on "Enable Remote Video Terminal"
     and press "Copy link".
  3. In the viewer press "+ Add drone", paste the link and give the drone a name.

To show it on other devices on the same network (tablet, second PC)
  Run "Start RVT Multi.cmd". It prints the address to open on the other devices.
  This needs Python installed on this computer. Leave its window open while in use.

Good to know
  - The viewer and the ground stations must be on the same network (LAN, Wi-Fi or VPN).
    No internet connection is needed.
  - Open the viewer from this folder, not from an https website: browsers do not allow
    a secure page to connect to a ground station.
  - A ground station's link carries an access key. By default the key changes each time
    its Video Terminal is turned on; add the drone again with the new link when it does.
  - The viewer only watches. It cannot command an aircraft.

SkyShield Technology - https://skyshieldtech.in
